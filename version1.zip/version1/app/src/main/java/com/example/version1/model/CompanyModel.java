package com.example.version1.model;

public class CompanyModel {

    public String Id,comp_name,comp_pic;

    public CompanyModel(String id, String comp_name, String comp_pic) {
        Id = id;
        this.comp_name = comp_name;
        this.comp_pic = comp_pic;
    }

    public static int size()
    {
        return 0;
    }


        public String getId () {
            return Id;
        }

        public void setId (String id){
            Id = id;
        }

        public String getComp_name () {
            return comp_name;
        }

        public void setComp_name (String comp_name){
            this.comp_name = comp_name;
        }

        public String getComp_pic () {
            return comp_pic;
        }

        public void setComp_pic (String comp_pic){
            this.comp_pic = comp_pic;
        }


}
