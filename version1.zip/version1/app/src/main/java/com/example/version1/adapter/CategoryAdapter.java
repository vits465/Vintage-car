package com.example.version1.adapter;

import com.bumptech.glide.Glide;
import com.example.version1.R;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.version1.model.*;
import com.example.version1.util.*;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CViewHolder> {

    ArrayList<CompanyModel> companyModels;

    public CategoryAdapter(ArrayList<CompanyModel> companyModels) {
        this.companyModels = companyModels;
    }

    @NonNull
    @Override
    public CViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_category, parent, false);
        return new CViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull CViewHolder holder, int position) {
    holder.tvcaname.setText(companyModels.get(position).getComp_name());
    Glide.with(holder.itemView.getContext()).load(ConstantData.SERVER_ADDRESS_IMG+companyModels.get(position).getComp_pic()).into(holder.imgcat);
    }

    @Override
    public int getItemCount() {
        return CompanyModel.size();
    }

    public class CViewHolder extends RecyclerView.ViewHolder {
        ImageView imgcat;
        TextView tvcaname;

        public CViewHolder(@NonNull View itemView) {
            super(itemView);
            imgcat=itemView.findViewById(R.id.imgCat);
            tvcaname=itemView.findViewById(R.id.tvCatname);
        }
    }
}
