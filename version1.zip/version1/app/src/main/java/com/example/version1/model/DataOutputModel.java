package com.example.version1.model;

import java.util.ArrayList;

public class DataOutputModel {
    public boolean status;
    public String message;
    public ArrayList<BannerModel> banner_data;
    public ArrayList<CompanyModel> company_data;
    public ArrayList<InputModel> input_data;
    public ArrayList<NegoModel> nego_data;
    public ArrayList<OrderModel> order_data;

    public DataOutputModel(boolean status, String message, ArrayList<BannerModel> banner_data, ArrayList<CompanyModel> company_data, ArrayList<InputModel> input_data, ArrayList<NegoModel> nego_data, ArrayList<OrderModel> order_data) {
        this.status = status;
        this.message = message;
        this.banner_data = banner_data;
        this.company_data = company_data;
        this.input_data = input_data;
        this.nego_data = nego_data;
        this.order_data = order_data;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public ArrayList<BannerModel> getBanner_data() {
        return banner_data;
    }

    public void setBanner_data(ArrayList<BannerModel> banner_data) {
        this.banner_data = banner_data;
    }

    public ArrayList<CompanyModel> getCompany_data() {
        return company_data;
    }

    public void setCompany_data(ArrayList<CompanyModel> company_data) {
        this.company_data = company_data;
    }

    public ArrayList<InputModel> getInput_data() {
        return input_data;
    }

    public void setInput_data(ArrayList<InputModel> input_data) {
        this.input_data = input_data;
    }

    public ArrayList<NegoModel> getNego_data() {
        return nego_data;
    }

    public void setNego_data(ArrayList<NegoModel> nego_data) {
        this.nego_data = nego_data;
    }

    public ArrayList<OrderModel> getOrder_data() {
        return order_data;
    }

    public void setOrder_data(ArrayList<OrderModel> order_data) {
        this.order_data = order_data;
    }
}

