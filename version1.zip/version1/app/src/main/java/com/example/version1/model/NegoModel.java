package com.example.version1.model;

public class NegoModel {
    public String id;
    public String uid;
    public String cid;
    public String desc;
    public String price;
    public String status;
    public String meeting_place;

    public NegoModel(String id, String uid, String cid, String desc, String price, String status, String meeting_place) {
        this.id = id;
        this.uid = uid;
        this.cid = cid;
        this.desc = desc;
        this.price = price;
        this.status = status;
        this.meeting_place = meeting_place;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getCid() {
        return cid;
    }

    public void setCid(String cid) {
        this.cid = cid;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMeeting_place() {
        return meeting_place;
    }

    public void setMeeting_place(String meeting_place) {
        this.meeting_place = meeting_place;
    }
}
