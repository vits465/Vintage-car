package com.example.version1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.version1.util.ConstantData;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import com.example.version1.api.*;

public class SingupActivity extends AppCompatActivity {

    //btn
    Button singup_btn;

    // varibaless
    Animation topAnim,bottomAnim,centeranim;
    ImageView logo;
    TextView logon_name,slogan,logo_text,r1t,rr1;
    String username,password,mobileno,email;

    EditText singup_name,singup_password,singup_email,singup_username,mobile_no;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_singup);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //ANImation
        topAnim = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomAnim = AnimationUtils.loadAnimation(this , R.anim.bottam_animation);
        centeranim = AnimationUtils.loadAnimation(this , R.anim.center_anim);

        //hooks
        logo =findViewById(R.id.logo);
        logo_text =findViewById(R.id.logo_text);
        logon_name=findViewById(R.id.logo_name);
        slogan =findViewById(R.id.slogan);
        singup_btn =findViewById(R.id.singup_btn);
        singup_name=findViewById(R.id.Singup_name);
        singup_email=findViewById(R.id.singup_email);
        singup_password =findViewById(R.id.singup_password);
        singup_username =findViewById(R.id.Singup_name);
        mobile_no =findViewById(R.id.mobile_no);
        r1t =findViewById(R.id.r1t);
        rr1 =findViewById(R.id.rr1);
        //anim
        logo.setAnimation(topAnim);
        logon_name.setAnimation(bottomAnim);
        slogan.setAnimation(bottomAnim);
        logo_text.setAnimation(bottomAnim);
        singup_btn.setAnimation(bottomAnim);
        singup_username.setAnimation(bottomAnim);
        mobile_no.setAnimation(bottomAnim);
        singup_password.setAnimation(bottomAnim);
        singup_email.setAnimation(bottomAnim);
        singup_name.setAnimation(bottomAnim);
        r1t.setAnimation(bottomAnim);
        rr1.setAnimation(bottomAnim);

        singup_btn.setOnClickListener(view -> {


            username=singup_username.getText().toString();
            password=singup_password.getText().toString();
            mobileno=mobile_no.getText().toString();
            email=singup_email.getText().toString();

          generateOTP(mobileno);


            new Login_Register_Api().register(SingupActivity.this,username,password,email,mobileno);
        });

    }

    public void generateOTP(String mobileno) {
        ExecutorService executor = Executors.newSingleThreadExecutor(); // Run in background thread
        executor.execute(() -> {
            OkHttpClient client = new OkHttpClient.Builder().build();
            MediaType mediaType = MediaType.parse("text/plain");
            RequestBody body = RequestBody.create(mediaType, "");

            Request request = new Request.Builder()
                    .url("https://cpaas.messagecentral.com/verification/v3/send?countryCode=91&customerId="+ ConstantData.CUSTOMER_ID+"&flowType=SMS&mobileNumber=" + mobileno)
                    .method("POST", body)
                    .addHeader("authToken", ConstantData.AUTH_TOKEN)
                    .build();

            try {
                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String responseBody = response.body().string();

                    JSONObject jsonResponse = new JSONObject(responseBody);

                    // Extract verificationId from the response
                    JSONObject data = jsonResponse.getJSONObject("data");
                    String verificationId = data.getString("verificationId");

                    // Send data to OTPActivity
                    runOnUiThread(() -> {
                        Intent intent = new Intent(SingupActivity.this, OTPActivity.class);
                        intent.putExtra("mobileno", mobileno);
                        intent.putExtra("username", username);
                        intent.putExtra("password", password);
                        intent.putExtra("email", email);
                        intent.putExtra("verificationId", verificationId); // Pass verificationId
                        startActivity(intent);
                    });
                } else {
                    runOnUiThread(() -> Toast.makeText(SingupActivity.this, "OTP request failed", Toast.LENGTH_SHORT).show());
                }
            } catch (IOException | JSONException e) {
                Log.e("ERROR", Objects.requireNonNull(e.getLocalizedMessage()));
                runOnUiThread(() -> Toast.makeText(SingupActivity.this, "Network error! Try again.", Toast.LENGTH_SHORT).show());
            }
        });
    }

}