package com.example.version1.api;

import android.app.ProgressDialog;
import android.content.Context;
import android.util.Log;
import android.view.PixelCopy;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.version1.util.*;
import com.example.version1.model.*;
import com.google.gson.Gson;
import com.example.version1.*;
public class Data_Api {

    public void  getdata(Context context) {
        ProgressDialog dialog = new ProgressDialog(context);
        dialog.setTitle("please Wait...");
        dialog.setCancelable(false);
        dialog.show();


        RequestQueue queue = Volley.newRequestQueue(context);
        StringRequest request = new StringRequest(
                Request.Method.GET,
                ConstantData.DATA_METHOD,
                response ->{
                    dialog.dismiss();
                    try{
                        DataOutputModel dataOutputModel = new Gson().fromJson(response, DataOutputModel.class);
                        Toast.makeText(context, "Data Get...", Toast.LENGTH_SHORT).show();
                        ((bnvActivity)context).getData(dataOutputModel);
                    }catch (Exception e){
                        Log.e("ERROR", e.toString());
                        Toast.makeText(context, "ERROR"+e.toString(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    dialog.dismiss();
                    Log.e("SERVER ERROR", error.toString());
                    Toast.makeText(context, "SERVER ERROR"+error.toString(), Toast.LENGTH_SHORT).show();
                }

        );
        queue.add(request);
    }

}
