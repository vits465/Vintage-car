package com.example.version1.model;

public class InputModel {
    public String car_price;
    public String car_desc;
    public String car_discount;
    public String pic1;
    public String pic2;
    public String pic3;
    public String pic4;
    public String limited_edition;
    public String old_year;
    public String engine;
    public String speciality;
    public String status;
    public String c_Id;
    public String car_name;

    public String getC_Id() {
        return c_Id;
    }

    public void setC_Id(String c_Id) {
        this.c_Id = c_Id;
    }

    public String getCar_name() {
        return car_name;
    }

    public void setCar_name(String car_name) {
        this.car_name = car_name;
    }

    public InputModel(String c_Id, String car_name) {
        this.c_Id = c_Id;
        this.car_name = car_name;

    }

    public String getCar_price() {
        return car_price;
    }

    public void setCar_price(String car_price) {
        this.car_price = car_price;
    }

    public String getCar_desc() {
        return car_desc;
    }

    public void setCar_desc(String car_desc) {
        this.car_desc = car_desc;
    }

    public String getCar_discount() {
        return car_discount;
    }

    public void setCar_discount(String car_discount) {
        this.car_discount = car_discount;
    }

    public String getPic1() {
        return pic1;
    }

    public void setPic1(String pic1) {
        this.pic1 = pic1;
    }

    public String getPic2() {
        return pic2;
    }

    public void setPic2(String pic2) {
        this.pic2 = pic2;
    }

    public String getPic3() {
        return pic3;
    }

    public void setPic3(String pic3) {
        this.pic3 = pic3;
    }

    public String getPic4() {
        return pic4;
    }

    public void setPic4(String pic4) {
        this.pic4 = pic4;
    }

    public String getLimited_edition() {
        return limited_edition;
    }

    public void setLimited_edition(String limited_edition) {
        this.limited_edition = limited_edition;
    }

    public String getOld_year() {
        return old_year;
    }

    public void setOld_year(String old_year) {
        this.old_year = old_year;
    }

    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public InputModel(String car_price, String car_desc, String car_discount, String pic1, String pic2, String pic3, String pic4, String limited_edition, String old_year, String engine, String speciality, String status) {
        this.car_price = car_price;
        this.car_desc = car_desc;
        this.car_discount = car_discount;
        this.pic1 = pic1;
        this.pic2 = pic2;
        this.pic3 = pic3;
        this.pic4 = pic4;
        this.limited_edition = limited_edition;
        this.old_year = old_year;
        this.engine = engine;
        this.speciality = speciality;
        this.status = status;

    }
}
