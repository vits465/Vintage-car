package com.example.version1.model;

public class BannerModel {
    public String Id;
    public String btitle;
    public String bpic;
    public String bdesc;

    public BannerModel(String url) {
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        this.Id = id;
    }

    public String getBtitle() {
        return btitle;
    }

    public void setBtitle(String btitle) {
        this.btitle = btitle;
    }

    public String getBpic() {
        return bpic;
    }

    public void setBpic(String bpic) {
        this.bpic = bpic;
    }

    public String getBdesc() {
        return bdesc;
    }

    public void setBdesc(String bdesc) {
        this.bdesc = bdesc;
    }

    public BannerModel(String id, String btitle, String bpic, String bdesc) {
        this.Id = id;
        this.btitle = btitle;
        this.bpic = bpic;
        this.bdesc = bdesc;

    }
}
