package com.example.version1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class login221Activity extends AppCompatActivity {

    //button
    Button login_btn;
    // varibales
    ImageView logo;
    TextView logo_text;
    EditText login_name,login_pwd;
    TextView txtSingup,txtFPass;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login221);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //hooks
        logo =findViewById(R.id.logo);
        logo_text =findViewById(R.id.logo_text);
        login_btn =findViewById(R.id.login_btn);
        login_name =findViewById(R.id.login_name);
        login_pwd=findViewById(R.id.login_pwd);
        txtSingup=findViewById(R.id.txtSingup);
        txtFPass=findViewById(R.id.txtFPass);

        //btnredirect
        login_btn.setOnClickListener(v -> {
            Intent intent=new Intent(login221Activity.this,bnvActivity.class);
            intent.putExtra("key",0);
            startActivity(intent);
            finish();
        });
        txtSingup.setOnClickListener(view -> {
            Intent intent=new Intent(login221Activity.this, SingupActivity.class);
            startActivity(intent);
            finish();
        });
    }
}