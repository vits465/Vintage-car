package com.example.version1.model;

public class OrderModel {
    public String id;

    public String u_Id;

    public String c_Id;
    public String date;
    public String time;
    public String price;

    public String c_o;
    public String address;
    public String licno;
    public String status;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getU_Id() {
        return u_Id;
    }

    public void setU_Id(String u_Id) {
        this.u_Id = u_Id;
    }

    public String getC_Id() {
        return c_Id;
    }

    public void setC_Id(String c_Id) {
        this.c_Id = c_Id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getC_o() {
        return c_o;
    }

    public void setC_o(String c_o) {
        this.c_o = c_o;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getLicno() {
        return licno;
    }

    public void setLicno(String licno) {
        this.licno = licno;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public OrderModel(String c_o, String id, String u_Id, String c_Id, String date, String time, String price, String address, String licno, String status) {
        this.c_o = c_o;
        this.id = id;
        this.u_Id = u_Id;
        this.c_Id = c_Id;
        this.date = date;
        this.time = time;
        this.price = price;
        this.address = address;
        this.licno = licno;
        this.status = status;

    }
}
