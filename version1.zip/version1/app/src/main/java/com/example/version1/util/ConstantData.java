package com.example.version1.util;

public class ConstantData {
//    http://192.168.1.8:8080/majorproject/Vintage/api/register_user.php
//    http://localhost:8080/majorproject/api/api_data.php
    public  static final String SERVER_ADDRESS="http://192.168.1.4:8080/majorproject/api/";
    public  static final String REGISTER_METHOD = SERVER_ADDRESS+"register_user.php";
    public  static final String DATA_METHOD = SERVER_ADDRESS+"api_data.php";

    public  static final String SERVER_ADDRESS_IMG = SERVER_ADDRESS+"/images";



    public static final String CUSTOMER_ID="C-72008F71EB56422";
    public static final String AUTH_TOKEN="eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJDLTcyMDA4RjcxRUI1NjQyMiIsImlhdCI6MTczODgyMjMzNywiZXhwIjoxODk2NTAyMzM3fQ.JBDxGYC_tVvJ6_QZxgBRX13J6FeyzvuCYE57WlWYS6vAw0YuTJemTiNuqaTWG_BH7gg5agXbir8C9GYq1fvWoQ";
}
