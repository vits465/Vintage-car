    package com.example.version1.api;

    import android.content.Context;
    import android.content.Intent;
    import android.widget.Toast;

    import androidx.annotation.Nullable;

    import com.android.volley.AuthFailureError;
    import com.android.volley.Request;
    import com.android.volley.RequestQueue;
    import com.android.volley.Response;
    import com.android.volley.VolleyError;
    import com.android.volley.toolbox.StringRequest;
    import com.example.version1.*;
    import com.example.version1.model.*;
    import com.android.volley.toolbox.Volley;
    import com.example.version1.util.ConstantData;
    import com.google.gson.Gson;

    import java.util.HashMap;
    import java.util.Map;

    public class Login_Register_Api {
        public  void register(Context context,String username,String password,String email,String mobileno){

            String URL=ConstantData.REGISTER_METHOD;

            RequestQueue requestQueue= Volley.newRequestQueue(context);
            StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        Gson gson=new Gson();
                        PersonOutputModel p=gson.fromJson(response,PersonOutputModel.class);
                        if (p.isStatus()) {
                            Toast.makeText(context, "User Registered Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(context, login221Activity.class);
                            context.startActivity(intent);
                        }
                    } catch (Exception e) {
                        Toast.makeText(context, "ERROR"+e.toString(), Toast.LENGTH_SHORT).show();
                    }

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "SERVER ERROR", Toast.LENGTH_SHORT).show();
                }
            }){
                @Nullable
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String,String> map=new HashMap<>();
                    map.put("username",username);
                    map.put("email",email);
                    map.put("phone",mobileno);
                    map.put("password",password);
                    return  map;
                }
            };

            requestQueue.add(stringRequest);


        }
    }
