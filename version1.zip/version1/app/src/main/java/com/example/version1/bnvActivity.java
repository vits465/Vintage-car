package com.example.version1;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.example.version1.api.*;


import com.example.version1.model.*;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import com.example.version1.fragment.*;
public class bnvActivity extends AppCompatActivity {


     BottomNavigationView bnv;

    public ArrayList<BannerModel> banner_data;
    public ArrayList<CompanyModel> company_data;
    public ArrayList<InputModel> input_data;
    public ArrayList<NegoModel> nego_data;
    public ArrayList<OrderModel> order_data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_bnv);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        bnv = findViewById(R.id.bnv);


        new Data_Api().getdata(this);
        bnv.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.menu_home) {
                addFragment( new homeFragment(banner_data,company_data,input_data,nego_data));
            } else if (item.getItemId() == R.id.menu_cart) {
                addFragment(new CartFragment());
            } else {
                addFragment(new ProfileFragment());
            }
            return true;
        });
    }
    public void addFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame,fragment);
        fragmentTransaction.commit();
    }

    public void getData(DataOutputModel data){
        banner_data=data.getBanner_data();
        company_data=data.getCompany_data();
        input_data=data.getInput_data();
        nego_data=data.getNego_data();
        order_data=data.getOrder_data();

        addFragment(new homeFragment(banner_data,company_data,input_data,nego_data));
    }
}