package com.example.version1.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.denzcoskun.imageslider.ImageSlider;
import com.denzcoskun.imageslider.constants.ScaleTypes;
import com.denzcoskun.imageslider.models.SlideModel;
import com.example.version1.R;
import com.example.version1.model.BannerModel;
import com.example.version1.model.CompanyModel;
import com.example.version1.model.InputModel;
import com.example.version1.model.NegoModel;
import com.example.version1.adapter.*;
import com.example.version1.util.ConstantData;

import java.util.ArrayList;

public class homeFragment extends Fragment {
    View view;
    ImageSlider imageSlider;

    RecyclerView rcylcat;

    public ArrayList<BannerModel> banner_data;
    public ArrayList<CompanyModel> company_data;
    public ArrayList<InputModel> input_data;
    public ArrayList<NegoModel> nego_data;

    public homeFragment(ArrayList<BannerModel> banner_data, ArrayList<CompanyModel> company_data, ArrayList<InputModel> input_data, ArrayList<NegoModel> nego_data) {
        this.banner_data = banner_data;
        this.company_data = company_data;
        this.input_data = input_data;
        this.nego_data = nego_data;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_home, container, false);
        return  view;
    }
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        imageSlider = view.findViewById(R.id.imageslider);
        rcylcat = view.findViewById(R.id.recylCat);
        rcylcat.setLayoutManager(new LinearLayoutManager(getContext(),RecyclerView.HORIZONTAL,false));
        setBanner_data(banner_data);

    }

    public void setBanner_data(ArrayList<BannerModel> banner_data) {
        ArrayList<SlideModel>imglist = new ArrayList<>();
        for(int i=0;i<banner_data.size();i++) {
            imglist.add(new SlideModel(banner_data.get(i).getBpic(),ScaleTypes.FIT));
            Toast.makeText(getActivity(), "IMAGE: "+(ConstantData.SERVER_ADDRESS_IMG + banner_data.get(i).bpic), Toast.LENGTH_SHORT).show();
        }
        imageSlider.setImageList(imglist);
        CategoryAdapter adapter=new CategoryAdapter(company_data);
        rcylcat.setAdapter(adapter);

    }
}
